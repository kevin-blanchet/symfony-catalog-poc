-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: catalog
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product_option`
--

DROP TABLE IF EXISTS `product_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_option` (
  `product_id` int NOT NULL,
  `option_id` int NOT NULL,
  PRIMARY KEY (`product_id`,`option_id`),
  KEY `IDX_38FA41144584665A` (`product_id`),
  KEY `IDX_38FA4114A7C41D6F` (`option_id`),
  CONSTRAINT `FK_38FA41144584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_38FA4114A7C41D6F` FOREIGN KEY (`option_id`) REFERENCES `option` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_option`
--

LOCK TABLES `product_option` WRITE;
/*!40000 ALTER TABLE `product_option` DISABLE KEYS */;
INSERT INTO `product_option` VALUES (1,71),(1,72),(1,73),(1,74),(1,75),(1,76),(1,77),(1,78),(1,79),(2,71),(2,72),(2,73),(2,74),(2,75),(2,76),(2,77),(2,78),(2,79),(3,71),(3,72),(3,73),(3,74),(3,75),(3,76),(3,77),(3,78),(3,79),(4,71),(4,72),(4,73),(4,74),(4,75),(4,76),(4,77),(4,78),(4,79),(5,71),(5,72),(5,73),(5,74),(5,75),(5,76),(5,77),(5,78),(5,79),(6,71),(6,72),(6,73),(6,74),(6,75),(6,76),(6,77),(6,78),(6,79),(7,71),(7,72),(7,73),(7,74),(7,75),(7,76),(7,77),(7,78),(7,79),(8,71),(8,72),(8,73),(8,74),(8,75),(8,76),(8,77),(8,78),(8,79),(9,71),(9,72),(9,73),(9,74),(9,75),(9,76),(9,77),(9,78),(9,79),(10,71),(10,72),(10,73),(10,74),(10,75),(10,76),(10,77),(10,78),(10,79),(11,71),(11,72),(11,73),(11,74),(11,75),(11,76),(11,77),(11,78),(11,79),(12,71),(12,72),(12,73),(12,74),(12,75),(12,76),(12,77),(12,78),(12,79),(13,71),(13,72),(13,73),(13,74),(13,75),(13,76),(13,77),(13,78),(13,79),(14,71),(14,72),(14,73),(14,74),(14,75),(14,76),(14,77),(14,78),(14,79),(15,71),(15,72),(15,73),(15,74),(15,75),(15,76),(15,77),(15,78),(15,79),(16,71),(16,72),(16,73),(16,74),(16,75),(16,76),(16,77),(16,78),(16,79),(17,71),(17,72),(17,73),(17,74),(17,75),(17,76),(17,77),(17,78),(17,79),(18,71),(18,72),(18,73),(18,74),(18,75),(18,76),(18,77),(18,78),(18,79),(19,71),(19,72),(19,73),(19,74),(19,75),(19,76),(19,77),(19,78),(19,79),(20,71),(20,72),(20,73),(20,74),(20,75),(20,76),(20,77),(20,78),(20,79),(21,80),(21,81),(21,82),(21,83),(21,84),(22,80),(22,81),(22,82),(22,83),(22,84),(23,80),(23,81),(23,82),(23,83),(23,84),(24,80),(24,81),(24,82),(24,83),(24,84),(25,80),(25,81),(25,82),(25,83),(25,84),(26,80),(26,81),(26,82),(26,83),(26,84),(27,80),(27,81),(27,82),(27,83),(27,84),(28,80),(28,81),(28,82),(28,83),(28,84),(29,80),(29,81),(29,82),(29,83),(29,84),(30,80),(30,81),(30,82),(30,83),(30,84),(31,80),(31,81),(31,82),(31,83),(31,84),(32,80),(32,81),(32,82),(32,83),(32,84),(33,80),(33,81),(33,82),(33,83),(33,84),(34,80),(34,81),(34,82),(34,83),(34,84),(35,80),(35,81),(35,82),(35,83),(35,84),(36,80),(36,81),(36,82),(36,83),(36,84),(37,80),(37,81),(37,82),(37,83),(37,84),(38,80),(38,81),(38,82),(38,83),(38,84),(39,80),(39,81),(39,82),(39,83),(39,84),(40,80),(40,81),(40,82),(40,83),(40,84),(41,71),(41,72),(41,73),(41,74),(41,75),(41,76),(41,77),(41,78),(41,79),(43,80),(43,81),(43,82),(43,83),(43,84),(44,80),(44,81),(44,82);
/*!40000 ALTER TABLE `product_option` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-14  2:12:20
